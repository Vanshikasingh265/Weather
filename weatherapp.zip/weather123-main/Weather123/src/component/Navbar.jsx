import React from 'react'
import "./styel.scss"
const Navbar = () => {
  return (
    <div className='jano'>
    <img src={logo} alt="" />
    Weather jaano
      </div>
  )
}

export default Navbar
